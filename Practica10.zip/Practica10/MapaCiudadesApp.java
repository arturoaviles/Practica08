package Practica10;

import java.io.*;
import java.security.KeyStore.Entry;
import java.util.*;

/* Clase MapaCiudadesApp.java
Autor 1: Arturo Avilés Castellanos A01372760
Autor 2: Yael Araizaga Gracia  A01166495
Fecha: 26 de noviembre de 2014
Practica 10 Mapas*/

public class MapaCiudadesApp {
	
	public static void main(String[] args)  throws FileNotFoundException{
		
		HashMap<String, LinkedList<String>> mapa = new HashMap<String, LinkedList<String>>();
		
		Scanner sc = new Scanner(new FileReader("EstadoCiudades.txt"));
		String ciudad, estado;
		
		try {

			while (sc.hasNext()) {
				LinkedList<String> ciudades = new LinkedList<>();
				estado = sc.next();
				ciudad = sc.next();
				if(!mapa.containsKey(estado)){
					ciudades.add(ciudad);
					mapa.put(estado, ciudades);
				}
				else{
					ciudades = mapa.get(estado);
					
					if(!ciudades.contains(ciudad))
						ciudades.add(ciudad);
				}
					
			}
			
			
		 } catch (InputMismatchException e) {
			 System.err.println(e);
		 } catch (java.util.NoSuchElementException e){
			 System.err.println(e);
		 }
		 finally{
			 sc.close();
         }
		
		Set<Map.Entry<String, LinkedList<String>>> superset = mapa.entrySet();
		
		Iterator<Map.Entry<String, LinkedList<String>>> it = superset.iterator();
		
		while (it.hasNext()){
			Map.Entry<String, LinkedList<String>> currEntry = it.next();
			
			System.out.println("Estado: " + currEntry.getKey());
			
			System.out.println("Ciudades: " + currEntry.getValue().toString());

		}
		
		
	}

}
