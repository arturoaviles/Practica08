package Practica10;

import java.io.*;
import java.security.KeyStore.Entry;
import java.util.*;

/* Clase MapaPeliculasApp.java
Autor 1: Arturo Avilés Castellanos A01372760
Autor 2: Yael Araizaga Gracia  A01166495
Fecha: 26 de noviembre de 2014
Practica 10 Mapas*/

public class MapaPeliculasApp {
	
	public static void main(String[] args) throws FileNotFoundException{

		TreeMap<String, ArrayList<Integer>> mapa = new TreeMap<String, ArrayList<Integer>>();
		
		Scanner sc = new Scanner(new FileReader("RankingPeliculas.txt"));
		String pelicula, califi;
		String mejor ="";
		String peor = "";
		Integer calif;
		double promedio;
		double lower = 5.0 ;
		double higher = 0.0;
		
		try {

			while (sc.hasNext()) {
				ArrayList<Integer> calificaciones = new ArrayList<Integer>();
				pelicula = sc.nextLine();
				califi = sc.nextLine();
				calif = new Integer(califi);
				if(!mapa.containsKey(pelicula)){
					calificaciones.add(calif);
					mapa.put(pelicula, calificaciones);
				}
				else{
					calificaciones = mapa.get(pelicula);
					calificaciones.add(calif);
				}
				
				promedio = 0.0;
				for(int i = 0; i < calificaciones.size(); i++){
					promedio += calificaciones.get(i);
				}
				
				promedio = promedio / calificaciones.size();
				
				if(promedio > higher){
					higher = promedio;
					mejor = pelicula;
				}
				
				if(promedio < lower){
					lower = promedio;
					peor = pelicula;
				}
					
			}
			
			
		 } catch (InputMismatchException e) {
			 System.err.println(e);
		 } catch (java.util.NoSuchElementException e){
			 System.err.println(e);
		 }
		 finally{
			 sc.close();
         }
		
		
		Set<Map.Entry<String, ArrayList<Integer>>> superset = mapa.entrySet();
		
		Iterator<Map.Entry<String, ArrayList<Integer>>> it = superset.iterator();
		
		while(it.hasNext()){
			Map.Entry<String, ArrayList<Integer>> currEntry = it.next();
			
			System.out.println("Pelicula: " + currEntry.getKey());
			
			System.out.println("Votaciones: " + currEntry.getValue().toString());
		}
		
		System.out.println("\nMejor pelicula: " + mejor + " Ranking: " + higher + "\n\n");
		System.out.println("Peor pelicula: " + peor + " Ranking: " + lower + "\n\n");
		
	}

}
