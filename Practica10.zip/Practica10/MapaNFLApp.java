package Practica10;

import java.security.KeyStore.Entry;
import java.util.*;

/* Clase MapaNFLApp.java
Autor 1: Arturo Avilés Castellanos A01372760
Autor 2: Yael Araizaga Gracia  A01166495
Fecha: 26 de noviembre de 2014
Practica 10 Mapas*/

public class MapaNFLApp {
	
	public static void main(String[] args) {
		
		TreeMap<String, String> mapa = new TreeMap<String, String>();
		
		String[] estados = {"San Francisco", "Denver", "Miami", "Oakland", "Buffalo", "Kansas City", "San Diego",
							"Greenbay", "Chicago", "Seattle", "Detroit", "New York", "New England", "Sant Louis",
							"Cleveland", "Pittsburgh"};
		
		String[] equipos = {"Forty-niners", "Broncos", "Dolphins", "Raiders", "Bills", "Chiefs", "Chargers", "Packers",
							"Bears", "Seahawks", "Lions", "Jets", "Patriots", "Rams", "Browns", "Stealers"};
		
		for(int v = 0; v < estados.length; v++){
			mapa.put(estados[v], equipos[v]);
		}
		
		System.out.println(mapa.toString() + "\n");
		
		System.out.println("El tamanio del mapa es: " + mapa.size() + "\n");
		
		System.out.println("El equipo de Chicago es: " + mapa.get("Chicago") + "\n");
		
		System.out.println("Mapa actualizado con San Francisco: Niners " + mapa.put("San Francisco", "Niners") + "\n");
		
		System.out.println(mapa.toString() + "\n");

		System.out.println("San Diego tiene un equipo? ");
		
		if(mapa.containsKey("San Diego"))
			System.out.print("SI" + "\n\n");
		else
			System.out.print("NO" + "\n\n");

		System.out.println("Eliminando a Danver del mapa \n");
		
		mapa.remove("Denver");
		
		System.out.println(mapa.toString() + "\n");

		System.out.println("Agregando Dallas Cowboys \n");
		
		mapa.put("Dallas", "Cowboys");
		
		System.out.println(mapa.toString() + "\n");
		
		System.out.println("Ciudad lexicograficamente menor: " + mapa.firstKey() + "\n");
				
		System.out.println("Ciudad lexicograficamente mayor con su equipo: " + mapa.lastEntry() + "\n\n");
		
		System.out.println("*** Llaves de la 'm' a la 'r' borradas ***\n");


		Set<String> llaves = mapa.keySet();
		
		Iterator<String> it = llaves.iterator();
		
		while(it.hasNext()){
			String currKey = it.next();
			
			if(currKey.toLowerCase().compareTo("m") >= 0 && currKey.toLowerCase().compareTo("r") <= 0){
				it.remove();
			}
		}
		
		System.out.println(mapa.toString() + "\n");

		TreeMap<String, String> nuMapa = new TreeMap<String, String>();

		//Esta cosa magica es lo que permite hacer set de entries. Fuck yo set
		Set<Map.Entry<String, String>> entradas = mapa.entrySet();
		
		Iterator<Map.Entry<String, String>> iter = entradas.iterator();
		
		while (iter.hasNext()){
		Map.Entry<String, String> currEntry = iter.next();
		
		if(currEntry.getValue().toLowerCase().startsWith("c") || currEntry.getValue().toLowerCase().startsWith("b") ||
				currEntry.getValue().toLowerCase().startsWith("s"))
			nuMapa.put(currEntry.getKey(), currEntry.getValue());
		
		}
		
		System.out.println("*** TreeMap con los equipos que empiezan con B, C y S ***\n");

		
		System.out.println(nuMapa.toString() + "\n");
			
		
	}

}
