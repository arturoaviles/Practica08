package Practica10;

import java.util.*;
import java.io.FileReader;
import java.io.FileNotFoundException;

/* Clase MapaPeliculasApp.java
Autor 1: Arturo Avilés Castellanos A01372760
Autor 2: Yael Araizaga Gracia  A01166495
Fecha: 26 de noviembre de 2014
Práctica # 10 – Maps */

public class MapaPeliculasApp {
    public static void main(String[] args) throws FileNotFoundException{
        
        TreeMap<String, ArrayList<Integer>> peliculasConR = new TreeMap<String, ArrayList<Integer>>();
        
        Scanner lector = new Scanner(new FileReader("RankingPeliculas.txt"));
        while(lector.hasNext()){
            String nombre = lector.nextLine();
            String valorString = lector.nextLine();
            int valorInt = Integer.parseInt(valorString);
            //System.out.println(nombre +"***"+valorInt);
            
            if(!peliculasConR.containsKey(nombre)){
                ArrayList<Integer> ranking = new ArrayList<Integer>();
                ranking.add(valorInt);
                peliculasConR.put(nombre, ranking); 
            }
            else{
                ArrayList<Integer> ranking = peliculasConR.get(nombre);
                if(!ranking.contains(valorInt))
                    ranking.add(valorInt); 
            }
        }
        
        Set<Map.Entry<String, ArrayList<Integer>>> set4 = peliculasConR.entrySet();
        Iterator<Map.Entry<String, ArrayList<Integer>>> it4 = set4.iterator();
        
        while(it4.hasNext()){
        Map.Entry<String, ArrayList<Integer>> entrada = it4.next();
        
            System.out.println("Película: "+entrada.getKey());
            System.out.println("   Votaciones"+entrada.getValue());
            double sum = 0;
            
            System.out.print("        Promedio de votaciones: ");
            for(int p : entrada.getValue()){ //For each en el ArrayList
                sum+=(double)p;
            }
            double promedio = sum/entrada.getValue().size();
            System.out.println(promedio);
            
            //Mejor Pelicula
            
            
            
            
            
        }
        System.out.println("");
        System.out.println("Mejor pelicula: ");
        System.out.println("");
        System.out.println("Peor pelicula: ");
    }
}
