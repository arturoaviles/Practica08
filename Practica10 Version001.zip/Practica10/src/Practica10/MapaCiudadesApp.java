package Practica10;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

/* Clase MapaCiudadesApp.java
Autor 1: Arturo Avilés Castellanos A01372760
Autor 2: Yael Araizaga Gracia  A01166495
Fecha: 26 de noviembre de 2014
Práctica # 10 – Maps */

public class MapaCiudadesApp {
    public static void main(String[] args) throws FileNotFoundException{
        
       HashMap<String, LinkedList<String>> mexico = new HashMap<String, LinkedList<String>>();
       Scanner EstadoCiudades = new Scanner(new FileReader("EstadoCiudades.txt"));
       
       while(EstadoCiudades.hasNextLine()){
            String linea = EstadoCiudades.nextLine();
            String[] linea_box = linea.split("	");
            String estado = linea_box[0];
            String ciudad = linea_box[1];
            
            // Tambien se puede hacer por un llave = lector.nest();
            // Verifica si ya existe la llave y si ya tiene ciudades
            if(!mexico.containsKey(estado)){
                LinkedList<String> lista = new LinkedList<String>();
                lista.add(ciudad);
                mexico.put(estado, lista);
            }
            else{
                LinkedList<String> lista = mexico.get(estado);
                if(!lista.contains(ciudad))
                    lista.add(ciudad);
            }   
       }
       
       Set<Map.Entry<String, LinkedList<String>>> set3 = mexico.entrySet();
       Iterator<Map.Entry<String, LinkedList<String>>> it3 = set3.iterator();
       
       while(it3.hasNext()){
       Map.Entry<String, LinkedList<String>> entrada = it3.next();
           
           Collections.sort(entrada.getValue());
           System.out.println("Estado: "+entrada.getKey());
           System.out.println("  Ciudades: "+entrada.getValue());
       }  
    }
}
