package Practica10;
import java.util.*;
/* Clase MapaNFLApp.java
Autor 1: Arturo Avilés Castellanos A01372760
Autor 2: Yael Araizaga Gracia  A01166495
Fecha: 26 de noviembre de 2014
Práctica # 10 – Maps */

public class MapaNFLApp {
    
    public static void main(String[] args) {
        String[] ciudades = {"San Francisco", "Denver", "Miami", "Oakland", "Buffalo", "Kansas City", "San Diego", "Greenbay", "Chicago", "Seattle", "Detroit", "New York", "New England", "Sant Louis", "Cleveland", "Pittsburgh"};
        String[] equipos = {"Forty-niners", "Broncos", "Dolphins", "Raiders", "Bills", "Chiefs", "Chargers", "Packers", "Bears", "Seahawks", "Lions", "Jets", "Patriots", "Rams", "Browns", "Stealers"};
        TreeMap<String, String> NFL = new TreeMap<String, String>();
        
        for (int i = 0; i < ciudades.length; i++) {
            NFL.put(ciudades[i], equipos[i]);
        }

        System.out.println("TreeMap: "+NFL);
        System.out.println("Tamaño: "+NFL.size());
        System.out.println("");
        
        //Agrega San Francisco e Imprime el Mapa
        NFL.put("San Francisco", "Niners");
        System.out.println("TreeMap con San Francisco actualizado: "+NFL);
        System.out.println("");
        
        //Imprime si San Diego tiene equipo o no
        System.out.print("San Diego tiene equipo: ");
        if(NFL.containsKey("San Diego"))
            System.out.println("SI");
        else
            System.out.println("NO");
        
        //Elimina a Denver del Mapa
        NFL.remove("Denver");
        System.out.println("");
        System.out.println("TreeMap con Denver eliminado: " + NFL);
        
        //Agrega al mapa a Dallas - Cowboys
        NFL.put("Dallas", "Cowboys");
        System.out.println("");
        System.out.println("TreeMap con Dallas Agregado: " + NFL);
        
        //Imprime la ciudad lexicográficamente menor
        System.out.println("");
        System.out.println("La ciudad lexicograficamente menor es: " + NFL.firstKey());
        
        //Imprime la ciudad lexicográficamente mayor, junto con su equipo
        System.out.println("");
        System.out.println("La ciudad lexicograficamente mayor es: " + NFL.lastKey());
        System.out.println("");
        System.out.println("El equipo de la ciudad lexicograficamente mayor es: " + NFL.get(NFL.lastKey()));
        
        //Iterador que recorre Mapa y Elimina equipos que su ciudad empiece con "M" hasta "R"
        Set<String> set1 = NFL.keySet();
        Iterator<String> it = set1.iterator();
        
        while(it.hasNext()){
        String ciudad = it.next();
        
        if(ciudad.compareToIgnoreCase("m") >= 0 && ciudad.compareToIgnoreCase("r") <= 0)
            it.remove();
        }
        
        //Imprime Mapa Final
        System.out.println("");
        System.out.println("TreeMap final: "+NFL);
        System.out.println("");
        
        //Imprime mapa nuevo con get values bcs
        TreeMap<String,String> bcs = new TreeMap<String, String>();
        Set<Map.Entry<String,String>> set2 = NFL.entrySet();  ///Map.Entry
        Iterator<Map.Entry<String,String>> it2 = set2.iterator();
        
        while(it2.hasNext()){
            Map.Entry<String, String> entrada = it2.next();
            String valor = entrada.getValue().toLowerCase();
            if(valor.startsWith("b") || valor.startsWith("c") || valor.startsWith("s"))
                bcs.put(entrada.getKey(), entrada.getValue());
            
        }
        System.out.println("TreeMap con los equipos que empiezan con B, C, y S");
        System.out.println(bcs);
    }    
}
