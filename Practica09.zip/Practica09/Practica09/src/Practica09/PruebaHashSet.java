package Practica09;

import java.io.FileReader;
import java.io.FileNotFoundException;
import java.util.*;

/* Clase PruebaHashSet.java
Autor 1: Arturo Avilés Castellanos A01372760
Autor 2: Yael Araizaga Gracia  A01166495
Fecha: 20 de noviembre de 2014
Práctica # 9 – Sets */

public class PruebaHashSet {
    public static void main(String[] args) throws FileNotFoundException{
        
        long start = System.currentTimeMillis();
        
        Scanner girlScan = new Scanner(new FileReader("girlnames.txt"));
        HashSet<String> hs = new HashSet<String>();
        
        while (girlScan.hasNextLine()){
            String line = girlScan.nextLine();
            String[] girlBox = line.split(" ");
            String girlname = girlBox[0];
            hs.add(girlname);
        }
        
        Scanner boyScan = new Scanner(new FileReader("boynames.txt"));
        ArrayList<String> repetidos = new ArrayList<String>(1000);
        
        while (boyScan.hasNextLine()){
            String line = boyScan.nextLine();
            String[] boyBox = line.split(" ");
            String boyname = boyBox[0];
            
            if(hs.contains(boyname)==true) repetidos.add(boyname);
            
            else{
                hs.add(boyname);
            }
        }

        System.out.println("Nombres en Común(Total="+repetidos.size()+"):");
        for (int i = 0; i < repetidos.size(); i++) {
            System.out.println(repetidos.get(i));
        }
        System.out.println("--------------");  
        
        long time = System.currentTimeMillis() - start;
        System.out.println("Tiempo de Ejecución:"+time+" milisegundos");
    }
}